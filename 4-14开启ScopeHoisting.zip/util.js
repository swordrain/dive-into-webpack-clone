export default 'Hello,Webpack';
