module.exports = function (content) {
  window.alert('Hello ' + content);
};
